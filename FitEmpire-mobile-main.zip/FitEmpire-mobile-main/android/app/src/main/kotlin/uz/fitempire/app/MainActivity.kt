package uz.fitempire.app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
